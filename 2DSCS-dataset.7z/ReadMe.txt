The folder named "instance" is the datasets used for evaluating the performance of the algorithm

The datasets are divided three sets: Set1, Set2, and Set3. Each set has three subsets,e.g., Set11, Set12, and Set13. Each subset has 15 instances.

The "Coil_1_1_1" is the data of coil for the first instance of the Set11 while the "Strip_1_1_1" is the data of strip. 


The format of the Coil_×_×_×:

W	L	B
.	.	.
.	.	.
.	.	.

The format of the Strip_×_×_×:

w	l
.	.
.	.
.	.