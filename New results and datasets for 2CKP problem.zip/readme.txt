This file is 64 new best solutions obtained by hybrid-biased genetic algorithm for the two-dimensinal circular knapsack packing problem[1,2], 

The txt file is the coordinates of the rectangles and the objective value. And the svg file can be opened directly by browser or Visio(recommended). 

The meaning of file name “rect1-r1-area-rot” is as follows:

the instances name - the radius of the circle - the objective - items can rot

We provide the benchmark datasets used in paper.

[1]Bouzid, M. C., & Salhi, S. 2020. Packing rectangles into a fixed size circular container: Constructive and metaheuristic search approaches. European Journal of Operational Research, 285(3), 865-883.
[2]Silva, A., Coelho, L. C., Darvish, M., & Renaud, J. 2022. A cutting plane method and a parallel algorithm for packing rectangles in a circular container. European Journal of Operational Research, 303(1), 114-128.


Note: Once the paper is accepted by the journal, we will disclose the unzipped password of the file. 

