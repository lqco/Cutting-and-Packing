This file presents 64 new best solutions for the two-dimensinal circular knapsack packing problem (2CKP), which obtained by the paper entitled "Hybrid-biased genetic algorithm for packing unequal rectangles into a fixed-size circle".

The other papers addressed the 2CKP are: 
[1]Bouzid, M. C., & Salhi, S. 2020. Packing rectangles into a fixed size circular container: Constructive and metaheuristic search approaches. European Journal of Operational Research, 285(3), 865-883.
[2]Silva, A., Coelho, L. C., Darvish, M., & Renaud, J. 2022. A cutting plane method and a parallel algorithm for packing rectangles in a circular container. European Journal of Operational Research, 303(1), 114-128.
[3]López, C. O., & Beasley, J. E. 2018. Packing unequal rectangles and squares in a fixed size circular container using formulation space search. Computers & Operations Research, 94, 106-117.

The benchmark datasets used in paper are provided.