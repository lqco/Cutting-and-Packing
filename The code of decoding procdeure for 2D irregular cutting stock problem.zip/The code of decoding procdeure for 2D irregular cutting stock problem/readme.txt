This is the more detail code  of the heuristic decoding procdeure for the two dimensional irregualr cutting stock problem addressing by the paper: A decimal artificial bee colony with elite strategy for the cutting stock problem with irregular items.

Note: written in c++. 